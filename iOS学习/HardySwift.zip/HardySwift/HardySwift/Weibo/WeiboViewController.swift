//
//  WeiboViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/4.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class WeiboViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func setupData() -> Void
    {
        print("子类方法");
    }
    
    override  func setupBaseUI() -> Void
    {
         view.backgroundColor = UIColor.init(red: 110/255.0, green: 100/255.0, blue: 50/255.0, alpha: 1)
        navigationItem.title = "微博"
        
        print("打印标题" + (navTitle)!);
        setRightItemText(itemText: "Setting", action:#selector(ButtonClick))
    }
    
    override func startRequest() -> Void
    {
        
    }
    
    // @objc 表示可以直接供objectC 调用
    @objc func ButtonClick() -> Void
    {
        print("打印了");
    }
}
