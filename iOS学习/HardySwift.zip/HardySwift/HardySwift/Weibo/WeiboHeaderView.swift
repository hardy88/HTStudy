//
//  WeiboHeaderView.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class WeiboHeaderView: BaseView {

    public func initWithFrame(frame:CGRect){
        
        UIView.init(frame: frame)
        let iconImgView: UIImageView = UIImageView.init(frame: CGRect.init(x: 10, y: 10, width: 50, height: 50))
        iconImgView.layer.masksToBounds = true
        iconImgView.layer.cornerRadius = 25.0
        iconImgView.backgroundColor = UIColor.red
        
        
        
        
    }
}
