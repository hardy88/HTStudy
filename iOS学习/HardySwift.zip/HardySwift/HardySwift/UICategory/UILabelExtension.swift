//
//  UILabelCategray.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

extension UILabel{
    
    
    
    /// 扩展UILabel 构造方法
    ///
    /// - Parameters:
    ///   - frame: UIlabel frame值
    ///   - textStr: UIlabel text值
    convenience init(frame: CGRect, textStr:String)
    {
        self.init(frame: frame)
        text = textStr
        font = UIFont.mainTextFont()
        textColor = UIColor.mainUITextColor()
    }
    
    /// 设置主要文字属性
    ///
    /// - Parameter str: UILabel需要设置的text
    func setMainText(str:String){
        
        text = str
        font = UIFont.mainTextFont()
        textColor = UIColor.mainUITextColor()
        
    }
    /// 设置次要（描述性）文字属性
    ///
    /// - Parameter str: UILabel需要设置的text
    func setSubText(str:String) -> Void {
        text = str
        font = UIFont.subTextFont()
        textColor = UIColor.subUITextColor()
    }
    
}
