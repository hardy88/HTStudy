//
//  ProfileTableViewCell.swift
//  HardySwift
//
//  Created by hardy on 2017/12/6.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {
    
    open var iconView: UIImageView?
    open var titleLabel: UILabel?
    open var desLabel: UILabel?

   override init(style: UITableViewCellStyle, reuseIdentifier: String?)
   {
       super.init(style: style, reuseIdentifier: reuseIdentifier)
       setupBaseUI()
   }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    func setupBaseUI() -> Void
    {
        iconView = UIImageView.init(frame: CGRect.init(x: 5, y: 5, width: 30, height: 30))
        iconView?.backgroundColor = UIColor.lightGray
        addSubview(iconView!)
        
        titleLabel = UILabel.init(frame: CGRect.init(x: 40, y: 0, width: 100, height: 40))
        titleLabel?.text = "新的好友"
        addSubview(titleLabel!)
        
    }
}
