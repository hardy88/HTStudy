//
//  ProfileViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/3.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class ProfileViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
  

    // 私有方法
    var tbView:UITableView!  // 展示的tableView
    
    lazy var titleArr = Array(arrayLiteral: "我的好友","我的相册","我的赞","微博钱包","免流量","粉丝服务")
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func setupData() -> Void
    {
        
    }
    
    override  func setupBaseUI() -> Void
    {
        view.backgroundColor = UIColor.purple
        navigationItem.title = "个人中心"
        
        setRightItemText(itemText: "", action: #selector(toSetting))
        
        tbView = UITableView.init(frame:CGRect(x: 0, y: 64, width:UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height-64), style: UITableViewStyle.plain)
        tbView.delegate = self;
        tbView.dataSource = self;
        tbView.backgroundColor = UIColor.lightGray
        tbView.showsVerticalScrollIndicator = false
        view .addSubview(tbView)
    }
    
    override func startRequest() -> Void
    {
        
    }

    
    @objc func toSetting() -> Void
    {
        print("设置")
    }
    
    // tableView Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var n : Int = 0
        
        switch section
        {
            case 0:
                n = 1
                break
            case 1:
                n = 3
                break
            case 2:
                n=3
                break
            case 3:
                n = 3
                break
            case 4:
                n = 1
                break
            case 5:
                n = 1
                break
            default:
                 break
        }
        return n
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let  view:UIView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 10))
        view.backgroundColor = UIColor.lightGray
        return view
        
    }
    
   func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
   {
        if indexPath.section == 0
        {
            return 150
        }
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
    
        if indexPath.section == 0
        {
            let cellID: String = "CELL_ID"
            var  cell = tableView.dequeueReusableCell(withIdentifier: cellID)
            if (cell == nil)
            {
                cell = UITableViewCell.init(style: UITableViewCellStyle.default, reuseIdentifier: cellID)
            }
            let view : ProfileHeaderView = ProfileHeaderView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 150))
            cell?.addSubview(view)
            cell?.selectionStyle = UITableViewCellSelectionStyle.none
            return cell!
        }
        else
        {
            let cellID_PRO: String = "CELL_ID_MY"
            var cell:ProfileTableViewCell? = tableView.dequeueReusableCell(withIdentifier: cellID_PRO) as? ProfileTableViewCell
            if cell == nil
            {
                cell = ProfileTableViewCell.init(style: UITableViewCellStyle.default, reuseIdentifier: cellID_PRO)
            }
            cell?.titleLabel?.text = "我的相册"
            cell?.selectionStyle = UITableViewCellSelectionStyle.none
            return cell!
        }
    }
}
