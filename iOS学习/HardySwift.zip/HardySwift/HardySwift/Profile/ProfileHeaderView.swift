//
//  ProfileHeaderView.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class ProfileHeaderView: BaseView {
    
    
    public func initWithFrame(frame:CGRect)
    {
        
    }

    // 只能重载父类方法？
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        backgroundColor = UIColor.hex(hexString: "#FFFFFF")
        let iconImgView: UIImageView = UIImageView.init(frame: CGRect.init(x: 10, y: 10, width: 80, height: 80))
        iconImgView.layer.masksToBounds = true
        iconImgView.layer.cornerRadius = 40.0
        iconImgView.backgroundColor = UIColor.red
        addSubview(iconImgView)
        
        
        let  namelabel : UILabel = UILabel.init(frame: CGRect.init(x: 100, y: 15, width: 150, height: 20), textStr:"爱动脑筋的hardy")
        addSubview(namelabel)
        
        let desLabel:UILabel = UILabel.init(frame: CGRect.init(x: 100, y: 40, width: 150, height: 20))
        desLabel.setSubText(str: "简介:暂无介绍")
        addSubview(desLabel)
        
        let lineView:UIView = UIView.init(frame: CGRect.init(x: 0, y: 99, width: UIScreen.main.bounds.size.width, height: 1))
        lineView.backgroundColor = UIColor.hex(hexString: "#F0F0F0")
        addSubview(lineView)
        
        let weiboBut:UIButton = UIButton.init(type: UIButtonType.custom)
        weiboBut.frame = CGRect.init(x: 0, y: 100, width: UIScreen.main.bounds.size.width/3, height: 50)
        weiboBut.setTitle("微博", for: UIControlState.normal)
        weiboBut.setTitleColor(UIColor.mainUITextColor(), for: UIControlState.normal)
        addSubview(weiboBut)
    
        let guanzhuBut:UIButton = UIButton.init(type: UIButtonType.custom)
        guanzhuBut.frame = CGRect.init(x: UIScreen.main.bounds.size.width/3, y: 100, width: UIScreen.main.bounds.size.width/3, height: 50)
        guanzhuBut.setTitle("关注", for: UIControlState.normal)
        guanzhuBut.setTitleColor(UIColor.mainUITextColor(), for: UIControlState.normal)
        addSubview(guanzhuBut)
        
        let fansBut:UIButton = UIButton.init(type: UIButtonType.custom)
        fansBut.frame = CGRect.init(x: UIScreen.main.bounds.size.width*2/3, y: 100, width: UIScreen.main.bounds.size.width/3, height: 50)
        fansBut.setTitle("粉丝", for: UIControlState.normal)
        fansBut.setTitleColor(UIColor.mainUITextColor(), for: UIControlState.normal)
        addSubview(fansBut)
   
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
