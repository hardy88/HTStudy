//
//  HomeViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/3.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func setupData() -> Void
    {
        
    }
    override  func setupBaseUI() -> Void
    {
        view.backgroundColor = UIColor.red
        navigationItem.title = "首页"
    }
    
    override func startRequest() -> Void
    {
        
    }

}
