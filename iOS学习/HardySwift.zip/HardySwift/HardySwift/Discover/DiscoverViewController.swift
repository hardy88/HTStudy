//
//  DiscoverViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/4.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class DiscoverViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
   override func setupData() -> Void
    {
        
    }
    
   override  func setupBaseUI() -> Void
    {
        
    }
    
    override func startRequest() -> Void
    {
        
    }
}
