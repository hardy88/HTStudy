//
//  Helper.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit


//  final class 表示该类不能被继承
//  final func  表示该方法不能被子类重写
//  extension   分类中如果想要写一个构造函数，只能写便利型的构造函数, 同时要注意self.init方法调用，而不是super.init

/*
 convenience:便利，使用convenience修饰的构造函数叫做便利构造函数
 便利构造函数通常用在对系统的类进行构造函数的扩充时使用。
 便利构造函数的特点：
 1、便利构造函数通常都是写在extension里面
 2、便利函数init前面需要加载convenience
 3、在便利构造函数中需要明确的调用self.init()
 */

//  在子类中创建一个构造函数，必须要同时加上 required init?(coder aDecoder: NSCoder)方法;  如果子类中没有修改父类的如何方法，则不需要加required。  required修饰符只能用于修饰类初始化方法。
/*
 required修饰符的使用规则
 1.required修饰符只能用于修饰类初始化方法。
 2.当子类含有异于父类的初始化方法时（初始化方法参数类型和数量异于父类），子类必须要实现父类的required初始化方法，并且也要使用required修饰符而不是override。
 3.当子类没有初始化方法时，可以不用实现父类的required初始化方法。
 */

//  或者 override 父类的init方法

extension UIColor{
    
    
   //  convenience  便利构造函数,
    //  必须要父类有这个方法，才能用此方法
    convenience init(r:UInt32 ,g:UInt32 , b:UInt32 , a:CGFloat = 1.0) {
        self.init(red: CGFloat(r) / 255.0,
                  green: CGFloat(g) / 255.0,
                  blue: CGFloat(b) / 255.0,
                  alpha: a)
    }
    
    
    class func grb(r:CGFloat, g:CGFloat, b: CGFloat) ->UIColor{
        return UIColor.rgba(r: r, g: g, b: b, a: 1.0)
    }
    
    class func rgba(r:CGFloat, g:CGFloat, b: CGFloat, a:CGFloat) ->UIColor{
        return UIColor.init(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: a)
    }
   
    class func hex(hexString: String) ->UIColor
    {
        var cString: String = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        if cString.count < 6 { return UIColor.black }
        
        let index = cString.index(cString.endIndex, offsetBy: -6)
        let subString = cString[index...]
        if cString.hasPrefix("0X") { cString = String(subString) }
        if cString.hasPrefix("#") { cString = String(subString) }
        
        if cString.count != 6 { return UIColor.black }
        
        var range: NSRange = NSMakeRange(0, 2)
        let rString = (cString as NSString).substring(with: range)
        range.location = 2
        let gString = (cString as NSString).substring(with: range)
        range.location = 4
        let bString = (cString as NSString).substring(with: range)
        
        var r: UInt32 = 0x0
        var g: UInt32 = 0x0
        var b: UInt32 = 0x0
        
        Scanner(string: rString).scanHexInt32(&r)
        Scanner(string: gString).scanHexInt32(&g)
        Scanner(string: bString).scanHexInt32(&b)
        
        return UIColor(r: r, g: g, b: b)
    }
    
    
    /// 项目主要的背景色
    ///
    /// - Returns: UIColor对象
    class func mainBackGroundColor() ->UIColor
    {
        return UIColor.hex(hexString: "#FFFFFF")
    }
    
    
    /// 项目中UITableView Section HeaderView Color
    ///
    /// - Returns: UIColor对象
    class func tableViewSectionColor() ->UIColor{
        
        return UIColor.hex(hexString: "#F0F0F0")
    }
    
    
    /// 项目中主要文字的颜色
    ///
    /// - Returns: UIColor对象
    class func mainUITextColor() -> UIColor{
        
        return UIColor.hex(hexString: "#262626")
    }
    
    /// 项目中次要文字（描述性文字）的颜色
    ///
    /// - Returns: UIColor对象
    class func subUITextColor() -> UIColor{
        
        return UIColor.hex(hexString: "#8E8E8E")
    }
    
    /// 导航栏颜色
    ///
    /// - Returns: UIColor对象
    class func mainNavBackGroundColor() ->UIColor{
        
        return UIColor.hex(hexString: "#F5F5F5")
    }
}

