//
//  UIFontHelper.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit


// MARK: - 字体分类
extension UIFont {

    
    class func mainTextFont() ->UIFont{
        
        return UIFont.systemFont(ofSize: 15)
        
    }
    
    class func subTextFont() ->UIFont{
        
        return UIFont.systemFont(ofSize: 12)
    }
    
}
