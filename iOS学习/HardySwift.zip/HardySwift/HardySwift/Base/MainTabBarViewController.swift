//
//  MainTabBarViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/3.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class MainTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let weiboNav = BaseNavigationController.init(rootViewController: WeiboViewController())
        weiboNav.tabBarItem.title = "微博"
        weiboNav.tabBarItem.image = UIImage.init(named: "tabbar_home.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        weiboNav.tabBarItem.selectedImage = UIImage.init(named: "tabbar_home_highlighted.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        
        let disNav = BaseNavigationController.init(rootViewController: DiscoverViewController())
        disNav.tabBarItem.title = "发现"
        disNav.tabBarItem.image = UIImage.init(named: "tabbar_discover.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        disNav.tabBarItem.selectedImage = UIImage.init(named: "tabbar_discover_highlighted.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
   
        let homeNav = BaseNavigationController.init(rootViewController: HomeViewController())
        homeNav.tabBarItem.title = "首页"
        homeNav.tabBarItem.image = UIImage.init(named: "tabbar_compose_icon_add.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        homeNav.tabBarItem.selectedImage = UIImage.init(named: "tabbar_compose_icon_add_highlighted.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        
        let proNav = BaseNavigationController.init(rootViewController: ProfileViewController())
        proNav.tabBarItem.title = "我"
        proNav.tabBarItem.image = UIImage.init(named: "tabbar_profile.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        proNav.tabBarItem.selectedImage = UIImage.init(named: "tabbar_profile_highlighted.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        
        
        let msgNav = BaseNavigationController.init(rootViewController: MessageViewController())
        msgNav.tabBarItem.title = "消息"
        msgNav.tabBarItem.image = UIImage.init(named: "tabbar_message_center.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        msgNav.tabBarItem.selectedImage = UIImage.init(named: "tabbar_message_center_highlighted.png")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
        
        viewControllers = [weiboNav,msgNav,homeNav,disNav,proNav]
    }

}
