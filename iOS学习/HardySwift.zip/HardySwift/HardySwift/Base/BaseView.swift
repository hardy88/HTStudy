//
//  BaseView.swift
//  HardySwift
//
//  Created by hardy on 2017/12/5.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class BaseView: UIView {

}
