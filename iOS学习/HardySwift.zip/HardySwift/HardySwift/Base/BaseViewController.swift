//
//  BaseViewController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/4.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    
    // 定义属性 ?语法  可选，可以有值 也可以为空
    // 属性对外公开就是open
   open var navTitle: String?
   {
     return navigationItem.title
   }
    
    
    // 当前导航栏
    var currentNav :BaseNavigationController?
    {
        if navigationController is BaseNavigationController
        {
            // as 语法   as表示和右边类型一致
            return navigationController as? BaseNavigationController
        }
        return nil;
    }

    // 对外方法  Public
   public func setRightItemText(itemText:String, action:Selector?) -> Void
    {
        let item=UIBarButtonItem(title: itemText, style: UIBarButtonItemStyle.plain, target: self, action: action)
        
        navigationItem.rightBarButtonItem=item
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 初始化数据
        setupData()
        // 基本UI
        setupBaseUI()
        // 数据请求
        startRequest()
    }
    
    func setupData() -> Void
    {
        print("打印father方法")
    }
    
    func setupBaseUI() -> Void
    {
        print("打印father方法")
    }

    func startRequest() -> Void
    {
        print("打印father方法")
    }
}
