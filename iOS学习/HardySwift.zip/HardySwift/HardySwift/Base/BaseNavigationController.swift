//
//  BaseNavigationController.swift
//  HardySwift
//
//  Created by hardy on 2017/12/4.
//  Copyright © 2017年 Hardy Hu. All rights reserved.
//

import UIKit

class BaseNavigationController: UINavigationController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationBar.barTintColor = UIColor.mainNavBackGroundColor()
    }
}
